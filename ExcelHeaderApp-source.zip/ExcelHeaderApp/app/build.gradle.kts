plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.excel.header"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.excel.header"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // 应用签名密钥（随源码分发，见 keystore.properties / README.md）
    signingConfigs {
        create("release") {
            storeFile = file("release.keystore")
            storePassword = "Xh@2026ExcelPdfKey"
            keyAlias = "excelheader"
            keyPassword = "Xh@2026ExcelPdfKey"
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }

    // 修复：POI 及其传递依赖会带重复的 META-INF / module-info 资源，
    // AGP 8 下会报 duplicate resources，这里排除掉
    packaging {
        resources.excludes += setOf(
            "META-INF/DEPENDENCIES",
            "META-INF/LICENSE",
            "META-INF/LICENSE.txt",
            "META-INF/NOTICE",
            "META-INF/NOTICE.txt",
            "META-INF/ASL-2.0.txt",
            "META-INF/INDEX.LIST",
            "META-INF/*.kotlin_module",
            "module-info.class"
        )
    }

    lint {
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // 协程：替代裸 Thread 生成 PDF
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")

    // Apache POI - Excel 读取（支持 xlsx / xls / xlsm）
    // 修复：不再 exclude commons-compress / xmlbeans。
    // poi-ooxml 5.2.5 直接依赖 commons-compress(1.25.0) 与 xmlbeans(5.2.0)，
    // exclude 后打开 xlsx 会直接 NoClassDefFoundError。
    implementation("org.apache.poi:poi:5.2.5")
    implementation("org.apache.poi:poi-ooxml:5.2.5")
    implementation("org.apache.poi:poi-ooxml-lite:5.2.5")
}
