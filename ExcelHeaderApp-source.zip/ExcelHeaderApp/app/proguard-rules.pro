# 修复：补上被引用但缺失的 proguard-rules.pro
# 当前 release 未开启混淆(isMinifyEnabled=false)，此处仅作预留。

# Apache POI / XmlBeans 使用反射创建 schema 类，开启混淆时需保留
-keep class org.apache.poi.** { *; }
-keep class org.apache.xmlbeans.** { *; }
-keep class org.openxmlformats.** { *; }
-dontwarn java.awt.**
-dontwarn javax.swing.**
