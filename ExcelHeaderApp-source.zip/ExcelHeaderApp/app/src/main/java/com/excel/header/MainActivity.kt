package com.excel.header

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.view.MotionEvent
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.excel.header.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.apache.poi.ss.usermodel.Cell
import org.apache.poi.ss.usermodel.DataFormatter
import org.apache.poi.ss.usermodel.Sheet
import org.apache.poi.ss.usermodel.WorkbookFactory
import java.io.File

/**
 * 手机端「自定义页眉/页脚 + 打印」
 * 输出模型：单页 PDF —— 页面尺寸随表格（多宽多长就多宽多长），不切行、不分列。
 * 打印 = 打印预览 = 打印（设置即预览即实物）。
 * 文件处理：打开时复制一份到缓存，源文件删除不影响；打开新文件才替换缓存。
 * 所有设置只作用于打印输出，绝不修改源文件。
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // ===== 文件缓存副本 =====
    private var cacheFile: File? = null
    private var excelName = ""
    private var sheetName = ""
    private var pathHint = ""
    private var tableHeaders: List<String> = emptyList()
    private var tableRows: List<List<String>> = emptyList()
    private var cellComments: List<CellComment> = emptyList()
    private var sheetNames: List<String> = emptyList()
    private var activeSheet = 0

    // ===== 页眉/页脚：0普通 1首页 2奇数页 3偶数页 =====
    private val headerVariants = List(4) { HfVariant() }
    private val footerVariants = List(4) { HfVariant() }
    private var headerSeg = 0
    private var footerSeg = 0
    private var oddEvenSide = 2
    private var useFirstDiff = false
    private var useOddEven = false

    private var activeTab = 0          // 0页眉 1页脚 2页面 3工作表
    private var activeCol = 1

    private val collapseH by lazy { dp(16) }
    private var suppressSpinner = false

    private val pickExcel = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: SecurityException) {
                }
                loadExcel(uri)
            }
        }
    }

    // 字体：只用设备真实字体（系统 /system/fonts）+ 用户导入字体（filesDir/local_fonts）
    private val fontItems: MutableList<String> = mutableListOf("系统默认")
    private val fontPathByName = mutableMapOf<String, String>()
    private val localFontDir: File get() = File(filesDir, "local_fonts")
    private var defaultFontLabel = "系统默认"
    private var uninstallMode = false
    private var fontDialogRefresh: (() -> Unit)? = null

    private val pickFonts = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        localFontDir.mkdirs()
        var count = 0
        uris.forEach { uri ->
            try {
                val name = getFileName(uri).ifBlank { "font_${System.currentTimeMillis()}.ttf" }
                val dst = File(localFontDir, name)
                contentResolver.openInputStream(uri)?.use { input ->
                    dst.outputStream().use { input.copyTo(it) }
                }
                count++
            } catch (_: Exception) {
            }
        }
        if (count > 0) {
            buildFontItems()
            refreshFontAdapter()
            toast("已安装 $count 个字体")
            fontDialogRefresh?.invoke()
        }
    }

    private val pickImage = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        try {
            val bmp: Bitmap? = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it)
            }
            if (bmp == null) toast("图片解码失败")
            else {
                currentVariant().fmts[activeCol].image = bmp
                refreshPreview()
                toast("已在当前栏插入图片")
            }
        } catch (e: Exception) {
            toast("图片读取失败：${e.message}")
        }
    }

    private val requestWrite = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) generatePdf() else toast("需要存储权限才能保存到下载目录")
    }

    // ------------------------------------------------------------------ 生命周期

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupTabs()
        setupSegments()
        setupEditors()
        setupSpinners()
        setupToolbar()

        binding.btnPick.setOnClickListener {
            pickExcel.launch(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(
                    Intent.EXTRA_MIME_TYPES, arrayOf(
                        "application/vnd.ms-excel",
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "application/vnd.ms-excel.sheet.macroEnabled.12"
                    )
                )
            })
        }
        binding.btnSettings.setOnClickListener { showSettings() }
        binding.btnPrint.setOnClickListener { openPrintSettings() }
        binding.sheetName.setOnClickListener { pickSheet() }

        loadEditors()
        refreshFormatButtons()
        refreshPreview()
    }

    // ------------------------------------------------------------------ Tab

    private fun setupTabs() {
        listOf(binding.tabHeader, binding.tabFooter, binding.tabPage, binding.tabSheet)
            .forEachIndexed { i, tab -> tab.setOnClickListener { selectTab(i) } }
        selectTab(0)
    }

    private fun selectTab(index: Int) {
        saveEditors()
        activeTab = index

        binding.panelHeader.visibility = if (index == 0) View.VISIBLE else View.GONE
        binding.panelFooter.visibility = if (index == 1) View.VISIBLE else View.GONE
        binding.panelPage.visibility = if (index == 2) View.VISIBLE else View.GONE
        binding.panelSheet.visibility = if (index == 3) View.VISIBLE else View.GONE

        val texts = listOf(binding.tvTabHeader, binding.tvTabFooter, binding.tvTabPage, binding.tvTabSheet)
        val lines = listOf(binding.ulTabHeader, binding.ulTabFooter, binding.ulTabPage, binding.ulTabSheet)
        for (i in texts.indices) {
            texts[i].setTextColor(if (i == index) 0xFF2B5FC7.toInt() else 0xFF8F959E.toInt())
            lines[i].visibility = if (i == index) View.VISIBLE else View.INVISIBLE
        }

        if (index <= 1) {
            loadEditors()
            refreshFormatButtons()
        }
        refreshPreview()
    }

    // ------------------------------------------------------------------ 分段（普通/首页/奇偶）

    private fun setupSegments() {
        binding.segHeader0.setOnClickListener { selectSeg(0) }
        binding.segHeader1.setOnClickListener { selectSeg(1) }
        binding.segHeader2.setOnClickListener { selectSeg(2) }
        binding.segFooter0.setOnClickListener { selectSeg(0) }
        binding.segFooter1.setOnClickListener { selectSeg(1) }
        binding.segFooter2.setOnClickListener { selectSeg(2) }

        binding.segOdd.setOnClickListener { setOddEvenSide(2) }
        binding.segEven.setOnClickListener { setOddEvenSide(3) }
        binding.segOddF.setOnClickListener { setOddEvenSide(2) }
        binding.segEvenF.setOnClickListener { setOddEvenSide(3) }

        binding.cbFirstDiff.setOnCheckedChangeListener { _, checked ->
            useFirstDiff = checked
            refreshPreview()
        }
        binding.cbOddEvenDiff.setOnCheckedChangeListener { _, checked ->
            useOddEven = checked
            refreshPreview()
        }
    }

    private fun selectSeg(seg: Int) {
        saveEditors()
        if (activeTab == 1) footerSeg = seg else headerSeg = seg
        applySegUi()
        loadEditors()
        refreshFormatButtons()
        refreshPreview()
    }

    private fun setOddEvenSide(side: Int) {
        saveEditors()
        oddEvenSide = side
        applySegUi()
        loadEditors()
        refreshFormatButtons()
        refreshPreview()
    }

    private fun applySegUi() {
        val hSegs = listOf(binding.segHeader0, binding.segHeader1, binding.segHeader2)
        hSegs.forEachIndexed { i, v ->
            v.setBackgroundResource(if (i == headerSeg) R.drawable.bg_seg_active else R.drawable.bg_seg)
        }
        binding.oddEvenRow.visibility = if (headerSeg == 2) View.VISIBLE else View.GONE

        val fSegs = listOf(binding.segFooter0, binding.segFooter1, binding.segFooter2)
        fSegs.forEachIndexed { i, v ->
            v.setBackgroundResource(if (i == footerSeg) R.drawable.bg_seg_active else R.drawable.bg_seg)
        }
        binding.oddEvenRowF.visibility = if (footerSeg == 2) View.VISIBLE else View.GONE

        listOf(binding.segOdd, binding.segOddF).forEach {
            it.setBackgroundResource(if (oddEvenSide == 2) R.drawable.bg_seg_active else R.drawable.bg_seg)
        }
        listOf(binding.segEven, binding.segEvenF).forEach {
            it.setBackgroundResource(if (oddEvenSide == 3) R.drawable.bg_seg_active else R.drawable.bg_seg)
        }
    }

    // ------------------------------------------------------------------ 三栏编辑

    private fun setupEditors() {
        val colsH = listOf(binding.colH0, binding.colH1, binding.colH2)
        val colsF = listOf(binding.colF0, binding.colF1, binding.colF2)
        val etsH = editorsHeader()
        val etsF = editorsFooter()
        for (i in 0..2) {
            colsH[i].setOnClickListener { selectCol(i); focusEditor(etsH[i]) }
            colsF[i].setOnClickListener { selectCol(i); focusEditor(etsF[i]) }
            etsH[i].setOnClickListener { selectCol(i); focusEditor(etsH[i]) }
            etsF[i].setOnClickListener { selectCol(i); focusEditor(etsF[i]) }
            etsH[i].setOnFocusChangeListener { _, has -> if (has) selectCol(i) }
            etsF[i].setOnFocusChangeListener { _, has -> if (has) selectCol(i) }
        }
    }

    private fun editorsHeader(): List<EditText> = listOf(binding.etH0, binding.etH1, binding.etH2)
    private fun editorsFooter(): List<EditText> = listOf(binding.etF0, binding.etF1, binding.etF2)
    private fun editors(): List<EditText> =
        if (activeTab == 1) editorsFooter() else editorsHeader()

    private fun currentVariant(): HfVariant {
        val seg = if (activeTab == 1) footerSeg else headerSeg
        val variant = if (seg == 2) oddEvenSide else seg
        return if (activeTab == 1) footerVariants[variant] else headerVariants[variant]
    }

    private fun selectCol(col: Int) {
        saveEditors()
        activeCol = col
        highlightCols()
        refreshFormatButtons()
    }

    private fun highlightCols() {
        val colsH = listOf(binding.colH0, binding.colH1, binding.colH2)
        val colsF = listOf(binding.colF0, binding.colF1, binding.colF2)
        for (i in 0..2) {
            val bg = if (i == activeCol) R.drawable.bg_col_active else R.drawable.bg_col
            colsH[i].setBackgroundResource(bg)
            colsF[i].setBackgroundResource(bg)
        }
    }

    private fun saveEditors() {
        if (activeTab > 1) return
        val v = currentVariant()
        for (i in 0..2) v.texts[i] = editors()[i].text.toString()
    }

    private fun loadEditors() {
        if (activeTab > 1) return
        val v = currentVariant()
        for (i in 0..2) {
            val et = editors()[i]
            if (et.text.toString() != v.texts[i]) et.setText(v.texts[i])
        }
        highlightCols()
    }

    private fun focusEditor(et: EditText) {
        et.requestFocus()
        val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE)
            as android.view.inputmethod.InputMethodManager
        imm.showSoftInput(et, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
    }

    // ------------------------------------------------------------------ 工具栏：插入/格式

    private fun setupToolbar() {
        binding.btnInsPage.setOnClickListener { insertCode("&P") }
        binding.btnInsPages.setOnClickListener { insertCode("&N") }
        binding.btnInsDate.setOnClickListener { insertCode("&D") }
        binding.btnInsTime.setOnClickListener { insertCode("&T") }
        binding.btnInsFile.setOnClickListener { insertCode("&F") }
        binding.btnInsSheet.setOnClickListener { insertCode("&A") }
        binding.btnInsPath.setOnClickListener { insertCode("&Z&F") }
        binding.btnInsImage.setOnClickListener {
            if (activeTab > 1) toast("请先切到页眉/页脚页签") else pickImage.launch("image/*")
        }

        binding.btnBold.setOnClickListener { toggleFmt { it.bold = !it.bold } }
        binding.btnItalic.setOnClickListener { toggleFmt { it.italic = !it.italic } }
        binding.btnUnderline.setOnClickListener {
            toggleFmt {
                it.underline = !it.underline
                if (it.underline) it.doubleUnderline = false
            }
        }
        binding.btnUnderline2.setOnClickListener {
            toggleFmt {
                it.doubleUnderline = !it.doubleUnderline
                if (it.doubleUnderline) it.underline = false
            }
        }
        binding.btnStrike.setOnClickListener { toggleFmt { it.strike = !it.strike } }
        binding.btnSuper.setOnClickListener {
            toggleFmt {
                it.superscript = !it.superscript
                if (it.superscript) it.subscript = false
            }
        }
        binding.btnSub.setOnClickListener {
            toggleFmt {
                it.subscript = !it.subscript
                if (it.subscript) it.superscript = false
            }
        }
        binding.btnColor.setOnClickListener { pickColor() }

        setupToolbarDrag()
    }

    private fun insertCode(code: String) {
        if (activeTab > 1) {
            toast("请先切到页眉/页脚页签")
            return
        }
        val et = editors()[activeCol]
        val pos = et.selectionStart.coerceAtLeast(0)
        et.text.insert(pos, code)
    }

    private fun toggleFmt(block: (Fmt) -> Unit) {
        if (activeTab > 1) {
            toast("请先切到页眉/页脚页签")
            return
        }
        block(currentVariant().fmts[activeCol])
        refreshFormatButtons()
        refreshPreview()
    }

    private fun pickColor() {
        val names = arrayOf("黑色", "红色", "蓝色", "绿色", "灰色")
        val colors = intArrayOf(
            0xFF333333.toInt(), 0xFFD0021B.toInt(), 0xFF2B5FC7.toInt(),
            0xFF1E9E52.toInt(), 0xFF8F959E.toInt()
        )
        AlertDialog.Builder(this)
            .setTitle("字体颜色")
            .setItems(names) { _, which ->
                currentVariant().fmts[activeCol].color = colors[which]
                refreshPreview()
            }
            .show()
    }

    private fun refreshFormatButtons() {
        val f = currentVariant().fmts[activeCol]
        fun set(view: android.widget.TextView, on: Boolean) =
            view.setBackgroundResource(if (on) R.drawable.bg_tbtn_active else R.drawable.bg_tbtn)

        set(binding.btnBold, f.bold)
        set(binding.btnItalic, f.italic)
        set(binding.btnUnderline, f.underline)
        set(binding.btnUnderline2, f.doubleUnderline)
        set(binding.btnStrike, f.strike)
        set(binding.btnSuper, f.superscript)
        set(binding.btnSub, f.subscript)

        binding.btnUnderline.paintFlags =
            if (f.underline || f.doubleUnderline) binding.btnUnderline.paintFlags or Paint.UNDERLINE_TEXT_FLAG
            else binding.btnUnderline.paintFlags and Paint.UNDERLINE_TEXT_FLAG.inv()
        binding.btnStrike.paintFlags =
            if (f.strike) binding.btnStrike.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            else binding.btnStrike.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()

        suppressSpinner = true
        val fontIdx = if (f.font.isBlank()) 0
        else {
            val label = fontPathByName.entries.firstOrNull { it.value == f.font }?.key
            fontItems.indexOf(label ?: "系统默认")
        }
        binding.spFont.setSelection(fontIdx.coerceAtLeast(0))
        val sizes = resources.getStringArray(R.array.sizes)
        binding.spSize.setSelection(sizes.indexOf(f.size.toInt().toString()).coerceAtLeast(0))
        suppressSpinner = false
    }

    /** 系统真实字体：有什么显示什么，没有的不显示 */
    private fun buildFontItems() {
        fontItems.clear()
        fontItems.add("系统默认")
        fontPathByName.clear()

        java.io.File("/system/fonts").listFiles()
            ?.filter {
                it.name.endsWith(".ttf") || it.name.endsWith(".otf") || it.name.endsWith(".ttc")
            }
            ?.sortedBy { it.name.lowercase() }
            ?.forEach {
                val label = it.nameWithoutExtension
                fontItems.add(label)
                fontPathByName[label] = it.absolutePath
            }

        // 已安装（导入）字体
        localFontDir.listFiles()
            ?.filter {
                it.name.endsWith(".ttf") || it.name.endsWith(".otf") || it.name.endsWith(".ttc")
            }
            ?.sortedBy { it.name.lowercase() }
            ?.forEach {
                val label = it.nameWithoutExtension
                if (!fontItems.contains(label)) {
                    fontItems.add(label)
                    fontPathByName[label] = it.absolutePath
                }
            }
    }

    private fun refreshFontAdapter() {
        suppressSpinner = true
        binding.spFont.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, fontItems
        )
        suppressSpinner = false
        refreshFormatButtons()
    }

    private fun setupSpinners() {
        buildFontItems()
        refreshFontAdapter()
        binding.spFont.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (suppressSpinner) return
                if (pos < 0 || pos >= fontItems.size) return
                val name = fontItems[pos]
                currentVariant().fmts[activeCol].font =
                    if (name == "系统默认") "" else (fontPathByName[name] ?: "")
                refreshPreview()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        binding.spSize.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (suppressSpinner) return
                currentVariant().fmts[activeCol].size =
                    resources.getStringArray(R.array.sizes)[pos].toFloatOrNull() ?: 10f
                refreshPreview()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    // ------------------------------------------------------------------ 底部工具栏拖拽

    private fun setupToolbarDrag() {
        binding.toolbar.layoutParams.height = collapseH
        var startY = 0f
        var startH = 0
        var dragging = false

        binding.toolHandle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = true
                    startY = e.rawY
                    startH = binding.toolbar.height
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (dragging) {
                        val h = (startH + (startY - e.rawY)).toInt()
                            .coerceIn(collapseH, fullToolHeight())
                        binding.toolbar.layoutParams.height = h
                        binding.toolbar.requestLayout()
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        dragging = false
                        val full = fullToolHeight()
                        val open = if (Math.abs(e.rawY - startY) < dp(6))
                            binding.toolbar.height < collapseH + (full - collapseH) / 2
                        else
                            binding.toolbar.height > collapseH + (full - collapseH) * 0.35f
                        setToolbarOpen(open)
                    }
                    true
                }
                else -> false
            }
        }
        binding.toolbar.post { fullToolHeight() }
    }

    private fun fullToolHeight(): Int {
        binding.toolBody.measure(
            View.MeasureSpec.makeMeasureSpec(
                if (binding.toolbar.width > 0) binding.toolbar.width
                else resources.displayMetrics.widthPixels, View.MeasureSpec.EXACTLY
            ),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        return binding.toolBody.measuredHeight + collapseH
    }

    private fun setToolbarOpen(open: Boolean) {
        binding.toolbar.layoutParams.height = if (open) fullToolHeight() else collapseH
        binding.toolbar.requestLayout()
    }

    // ------------------------------------------------------------------ 页面设置

    private fun num(edit: EditText, def: Float): Float =
        edit.text.toString().toFloatOrNull() ?: def

    private fun buildSetup(): PageSetup {
        val s = PageSetup()
        s.marginTop = num(binding.etMarginTop, 2.54f) * PdfRenderer.PT_PER_CM
        s.marginBottom = num(binding.etMarginBottom, 2.54f) * PdfRenderer.PT_PER_CM
        s.marginLeft = num(binding.etMarginLeft, 1.91f) * PdfRenderer.PT_PER_CM
        s.marginRight = num(binding.etMarginRight, 1.91f) * PdfRenderer.PT_PER_CM
        s.headerTop = num(binding.etHeaderTop, 1.27f) * PdfRenderer.PT_PER_CM
        s.footerBottom = num(binding.etFooterBottom, 1.27f) * PdfRenderer.PT_PER_CM

        s.gridlines = binding.cbGridlines.isChecked
        s.mono = binding.cbMono.isChecked
        s.rowColHeaders = binding.cbRowCol.isChecked
        s.draft = binding.cbDraft.isChecked
        s.commentsMode =
            resources.getStringArray(R.array.comments)[binding.spComments.selectedItemPosition]

        // 打印区域：$A$1:$D$20
        val area = parsePrintArea(binding.etPrintArea.text.toString())
        s.printAreaCols = area?.first
        s.printAreaRows = area?.second
        return s
    }

    private fun colIndex(letters: String): Int {
        var n = 0
        for (ch in letters) n = n * 26 + (ch - 'A' + 1)
        return n - 1
    }

    /** 打印区域解析：$A$1:$D$20 → (列范围, 数据行范围)；数据行索引 = Excel 行号 - 2 */
    private fun parsePrintArea(str: String): Pair<IntRange, IntRange>? {
        val cells = Regex("[A-Za-z]+\\d+").findAll(str.trim()).toList()
        if (cells.size < 2) return null

        fun parse(s: String): Pair<Int, Int> {
            val letters = Regex("[A-Za-z]+").find(s)!!.value.uppercase()
            val row = Regex("\\d+").find(s)!!.value.toInt()
            return colIndex(letters) to row
        }

        val (c1, r1) = parse(cells[0].value)
        val (c2, r2) = parse(cells[1].value)
        val colR = minOf(c1, c2)..maxOf(c1, c2)
        val rowR = (minOf(r1, r2) - 2).coerceAtLeast(0)..(maxOf(r1, r2) - 2)
        return colR to rowR
    }

    // ------------------------------------------------------------------ 预览（= 打印）

    private fun refreshPreview() {
        val hSeg = if (headerSeg == 2) oddEvenSide else headerSeg
        val fSeg = if (footerSeg == 2) oddEvenSide else footerSeg
        val setup = buildSetup()
        val comments = cellComments

        binding.previewHeader.update(
            headerVariants[hSeg], footerVariants[fSeg], tableHeaders, tableRows, comments, setup
        )
        binding.previewFooter.update(
            headerVariants[hSeg], footerVariants[fSeg], tableHeaders, tableRows, comments, setup
        )
    }

    // ------------------------------------------------------------------ 文件：复制一份到缓存

    private fun loadExcel(uri: Uri) {
        val displayName = getFileName(uri)
        pathHint = getPathHint(uri)
        excelName = displayName.substringBeforeLast(".", displayName)

        try {
            // 复制一份到缓存：源文件删除/移动不影响；打开新文件才替换缓存
            val cache = File(cacheDir, "active.xlsx")
            contentResolver.openInputStream(uri)?.use { input ->
                cache.outputStream().use { input.copyTo(it) }
            } ?: throw IllegalStateException("无法打开文件")
            cacheFile = cache

            readWorkbook()
            binding.tvFileName.text = displayName
            binding.sheetName.text = "$sheetName（点按切换）"
            loadEditors()
            refreshPreview()
            toast("已载入缓存副本：$sheetName 共 ${tableRows.size} 行")
        } catch (e: Exception) {
            toast("读取失败：${e.message}")
        }
    }

    private fun readWorkbook() {
        val cache = cacheFile ?: return
        WorkbookFactory.create(cache.inputStream()).use { wb ->
            sheetNames = (0 until wb.numberOfSheets).map { wb.getSheetName(it) }
            if (activeSheet >= sheetNames.size) activeSheet = 0
            readSheet(wb, activeSheet)
        }
    }

    private fun readSheet(wb: org.apache.poi.ss.usermodel.Workbook, index: Int) {
        val sheet = wb.getSheetAt(index)
        sheetName = sheet.sheetName

        val hf = sheet.header
        headerVariants[0].texts[0] = hf.left ?: ""
        headerVariants[0].texts[1] = hf.center ?: ""
        headerVariants[0].texts[2] = hf.right ?: ""

        val ft = sheet.footer
        footerVariants[0].texts[0] = ft.left ?: ""
        footerVariants[0].texts[1] = ft.center ?: ""
        footerVariants[0].texts[2] = ft.right ?: ""

        readTableData(sheet)
    }

    private fun pickSheet() {
        if (cacheFile == null || sheetNames.isEmpty()) {
            toast("请先选择文件")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("选择工作表")
            .setItems(sheetNames.toTypedArray()) { _, which ->
                if (which != activeSheet) {
                    activeSheet = which
                    reloadSheet()
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun reloadSheet() {
        try {
            readWorkbook()
            binding.sheetName.text = "$sheetName（点按切换）"
            loadEditors()
            refreshPreview()
            toast("已切换到：$sheetName 共 ${tableRows.size} 行")
        } catch (e: Exception) {
            toast("切换失败：${e.message}")
        }
    }

    /** 全量读取（空格保留 → 边框完整）；公式取结果值；收集批注 */
    private fun readTableData(sheet: Sheet) {
        val formatter = DataFormatter()
        val evaluator = sheet.workbook.creationHelper.createFormulaEvaluator()

        fun text(cell: Cell?): String {
            if (cell == null) return ""
            return try {
                formatter.formatCellValue(cell, evaluator).trim()
            } catch (_: Exception) {
                cell.toString().trim()
            }
        }

        val totalRows = sheet.lastRowNum + 1
        if (totalRows <= 0) {
            tableHeaders = emptyList(); tableRows = emptyList(); cellComments = emptyList()
            return
        }
        var colCount = 0
        for (i in 0 until totalRows) {
            val row = sheet.getRow(i) ?: continue
            colCount = maxOf(colCount, row.lastCellNum.toInt())
        }
        if (colCount <= 0) {
            tableHeaders = emptyList(); tableRows = emptyList(); cellComments = emptyList()
            return
        }

        val headers = (0 until colCount).map { text(sheet.getRow(0)?.getCell(it)) }
        val rows = mutableListOf<List<String>>()
        val comments = mutableListOf<CellComment>()
        for (i in 1 until totalRows) {
            val row = sheet.getRow(i)
            rows.add((0 until colCount).map { text(row?.getCell(it)) })
            val tableIdx = rows.size - 1
            for (j in 0 until colCount) {
                row?.getCell(j)?.cellComment?.let { c ->
                    val msg = try {
                        c.string.string
                    } catch (_: Exception) {
                        ""
                    }
                    if (msg.isNotBlank()) comments.add(CellComment(tableIdx, j, msg))
                }
            }
        }
        tableHeaders = headers
        tableRows = rows
        cellComments = comments
    }

    private fun getFileName(uri: Uri): String {
        var name = "unknown.xlsx"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && idx >= 0) cursor.getString(idx)?.let { name = it }
        }
        return name
    }

    private fun getPathHint(uri: Uri): String = try {
        val docId = DocumentsContract.getDocumentId(uri)
        val seg = docId.substringAfter(':', "")
        if (seg.contains('/')) seg.substringBeforeLast('/') + "/" else ""
    } catch (_: Exception) {
        ""
    }

    // ------------------------------------------------------------------ 生成 PDF（单页，尺寸随表格）

    private fun generatePdf() {
        saveEditors()
        if (cacheFile == null) {
            toast("请先选择文件")
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            requestWrite.launch(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }

        val setup = buildSetup()
        val h = headerVariants.map { it.deepCopy() }
        val f = footerVariants.map { it.deepCopy() }
        val first = useFirstDiff
        val oddEven = useOddEven
        val th = tableHeaders
        val tr = tableRows
        val cm = cellComments
        val sheet = sheetName
        val name = excelName.ifBlank { "output" }
        val path = pathHint

        binding.btnPrint.alpha = 0.5f
        binding.btnPrint.text = "生成中..."

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val tmp = File(cacheDir, "print_tmp.pdf")
                    PdfRenderer.render(
                        tmp, h, f, first, oddEven, th, tr, cm, sheet, name, path, setup
                    )
                    saveToDownloads(tmp, "$name.pdf")
                }
            }
            binding.btnPrint.alpha = 1f
            binding.btnPrint.text = "🖨️ 打印 PDF"
            result.fold(
                onSuccess = { uri -> openPdf(uri, "$name.pdf") },
                onFailure = { toast("生成失败：${it.message}") }
            )
        }
    }

    private fun saveToDownloads(src: File, displayName: String): Uri {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                put(
                    android.provider.MediaStore.MediaColumns.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS
                )
            }
            val uri = contentResolver.insert(
                android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values
            ) ?: throw IllegalStateException("创建下载文件失败")
            contentResolver.openOutputStream(uri)?.use { out ->
                src.inputStream().use { it.copyTo(out) }
            } ?: throw IllegalStateException("写入下载目录失败")
            uri
        } else {
            @Suppress("DEPRECATION")
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!dir.exists()) dir.mkdirs()
            val dst = File(dir, displayName)
            src.copyTo(dst, overwrite = true)
            FileProvider.getUriForFile(this, "$packageName.fileprovider", dst)
        }
    }

    private fun openPdf(uri: Uri, displayName: String) {
        toast("已保存到下载目录：$displayName")
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "打开 PDF"))
        } catch (e: ActivityNotFoundException) {
            toast("未找到可打开 PDF 的应用")
        } catch (e: Exception) {
            toast("打开 PDF 失败：${e.message}")
        }
    }

    // ------------------------------------------------------------------ 弹窗

    private fun showSettings() {
        AlertDialog.Builder(this)
            .setTitle("设置")
            .setItems(
                arrayOf(
                    "版本：v1.0",
                    "字体",
                    "关于：Excel页眉打印"
                )
            ) { _, which ->
                if (which == 1) openFontManager()
            }
            .setNegativeButton("关闭", null)
            .show()
    }

    /** 打印设置（修改即生效；取消 / 打印） */
    private fun openPrintSettings() {
        if (cacheFile == null) {
            toast("请先选择文件")
            return
        }
        val v = layoutInflater.inflate(R.layout.dialog_print, null)
        val etMTop = v.findViewById<EditText>(R.id.pmMTop)
        val etMBottom = v.findViewById<EditText>(R.id.pmMBottom)
        val etMLeft = v.findViewById<EditText>(R.id.pmMLeft)
        val etMRight = v.findViewById<EditText>(R.id.pmMRight)
        val etHTop = v.findViewById<EditText>(R.id.pmHeaderTop)
        val etFBottom = v.findViewById<EditText>(R.id.pmFooterBottom)

        etMTop.setText(binding.etMarginTop.text)
        etMBottom.setText(binding.etMarginBottom.text)
        etMLeft.setText(binding.etMarginLeft.text)
        etMRight.setText(binding.etMarginRight.text)
        etHTop.setText(binding.etHeaderTop.text)
        etFBottom.setText(binding.etFooterBottom.text)

        fun apply() {
            binding.etMarginTop.setText(etMTop.text)
            binding.etMarginBottom.setText(etMBottom.text)
            binding.etMarginLeft.setText(etMLeft.text)
            binding.etMarginRight.setText(etMRight.text)
            binding.etHeaderTop.setText(etHTop.text)
            binding.etFooterBottom.setText(etFBottom.text)
            refreshPreview()
        }

        AlertDialog.Builder(this)
            .setTitle("打印设置")
            .setView(v)
            .setPositiveButton("打印") { _, _ ->
                apply()
                generatePdf()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    /** 字体管理：默认字体 + 已安装字体（滚动列表，卸载模式显示 x）+ 安装/卸载 */
    private fun openFontManager() {
        uninstallMode = false
        val view = layoutInflater.inflate(R.layout.dialog_fonts, null)
        val tvDefault = view.findViewById<TextView>(R.id.tvDefaultFontValue)
        val listWrap = view.findViewById<android.widget.LinearLayout>(R.id.fontList)
        val btnInstall = view.findViewById<TextView>(R.id.btnFontInstall)
        val btnUninstall = view.findViewById<TextView>(R.id.btnFontUninstall)

        fun renderDefault() {
            tvDefault.text = defaultFontLabel
        }

        fun renderList() {
            listWrap.removeAllViews()
            val installed = localFontDir.listFiles()
                ?.filter {
                    it.name.endsWith(".ttf") || it.name.endsWith(".otf") || it.name.endsWith(".ttc")
                }
                ?.sortedBy { it.name.lowercase() } ?: emptyList()
            if (installed.isEmpty()) {
                val empty = TextView(this)
                empty.text = "（暂无已安装字体，点“安装”导入，如 simsun.ttc / kaiti.ttf）"
                empty.textSize = 12f
                empty.setTextColor(0xFF8F959E.toInt())
                empty.setPadding(0, dp(10), 0, dp(10))
                listWrap.addView(empty)
            }
            installed.forEach { f ->
                val row = android.widget.LinearLayout(this)
                row.orientation = android.widget.LinearLayout.HORIZONTAL
                row.gravity = android.view.Gravity.CENTER_VERTICAL
                row.setPadding(0, dp(10), 0, dp(10))
                val label = TextView(this)
                label.text = f.nameWithoutExtension
                label.textSize = 14f
                label.layoutParams = android.widget.LinearLayout.LayoutParams(
                    0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                )
                row.addView(label)
                if (uninstallMode) {
                    val x = TextView(this)
                    x.text = "✕"
                    x.textSize = 15f
                    x.setTextColor(0xFFD0021B.toInt())
                    x.setPadding(dp(14), 0, dp(4), 0)
                    x.setOnClickListener {
                        val name = f.nameWithoutExtension
                        f.delete()
                        buildFontItems()
                        refreshFontAdapter()
                        renderList()
                        toast("已卸载：$name")
                    }
                    row.addView(x)
                }
                listWrap.addView(row)
            }
        }

        fontDialogRefresh = { renderList() }

        tvDefault.setOnClickListener {
            val labels = fontItems.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("选择默认字体")
                .setItems(labels) { _, which ->
                    defaultFontLabel = labels[which]
                    PdfRenderer.defaultFont = fontPathByName[defaultFontLabel] ?: ""
                    renderDefault()
                    refreshPreview()
                }
                .setNegativeButton("取消", null)
                .show()
        }

        btnInstall.setOnClickListener { pickFonts.launch(arrayOf("*/*")) }
        btnUninstall.setOnClickListener {
            uninstallMode = !uninstallMode
            btnUninstall.text = if (uninstallMode) "完成卸载" else "卸载"
            renderList()
        }

        renderDefault()
        renderList()
        AlertDialog.Builder(this)
            .setView(view)
            .setOnDismissListener { fontDialogRefresh = null }
            .show()
    }

    private fun toast(msg: String) =
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    companion object {
    }
}
