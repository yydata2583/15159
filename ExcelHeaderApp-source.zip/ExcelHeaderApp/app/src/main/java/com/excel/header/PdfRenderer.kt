package com.excel.header

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/** 单栏格式（粗/斜/单双下划线/删除线/上标/下标/字体/字号/颜色/插图） */
data class Fmt(
    var bold: Boolean = false,
    var italic: Boolean = false,
    var underline: Boolean = false,
    var doubleUnderline: Boolean = false,
    var strike: Boolean = false,
    var superscript: Boolean = false,
    var subscript: Boolean = false,
    var font: String = "宋体",
    var size: Float = 10f,
    var color: Int = 0xFF333333.toInt(),
    var image: Bitmap? = null
)

/** 页眉/页脚变体（左中右三栏） */
data class HfVariant(
    val texts: MutableList<String> = MutableList(3) { "" },
    val fmts: MutableList<Fmt> = MutableList(3) { Fmt() }
) {
    fun deepCopy(): HfVariant = HfVariant(
        texts.toMutableList(),
        fmts.map { it.copy() }.toMutableList()
    )
}

data class CellComment(val row: Int, val col: Int, val text: String)

/**
 * 页面设置（无纸张概念：输出为单页 PDF，页面尺寸随表格内容，不切行、不分列）
 * 所有设置只作用于打印输出，绝不修改源文件。
 */
data class PageSetup(
    var marginLeft: Float = 54f,
    var marginRight: Float = 54f,
    var marginTop: Float = 72f,
    var marginBottom: Float = 72f,
    var headerTop: Float = 36f,
    var footerBottom: Float = 36f,
    var gridlines: Boolean = true,
    var mono: Boolean = false,
    var rowColHeaders: Boolean = false,
    var draft: Boolean = false,
    var commentsMode: String = "无",     // 无 / 工作表末尾 / 如同工作表中的显示
    var printAreaRows: IntRange? = null, // 打印区域（数据行索引），null＝全部
    var printAreaCols: IntRange? = null  // 打印区域（列索引），null＝全部
)

/** 页面几何：预览与打印共用同一计算 → 所见即所得 */
data class PageGeom(
    val pageW: Float,
    val pageH: Float,
    val bodyTop: Float,
    val headers: List<String>,       // 渲染表头（含行号列标列）
    val rows: List<List<String>>,    // 渲染数据行（已裁剪打印区域、含行号列标列）
    val colW: List<Float>,
    val rowH: Float,
    val headH: Float,
    val letterH: Float,
    val tableH: Float
)

/**
 * 单页 PDF 渲染：页面宽 = 左边距 + 表格宽 + 右边距；页面长 = 表格长 + 页眉页脚空间。
 * 页眉（如有）→ 表格（全部内容，空格带边框）→ 页脚（如有）
 */
object PdfRenderer {

    const val PT_PER_CM = 28.3495f
    private const val LITERAL = "\u0001"

    // ---------------- 几何（预览/打印共用） ----------------
    fun calcGeom(
        tableHeaders: List<String>,
        tableRows: List<List<String>>,
        comments: List<CellComment>,
        setup: PageSetup
    ): PageGeom {
        val colR = setup.printAreaCols ?: (0 until max(1, tableHeaders.size))
        val rowR = setup.printAreaRows ?: (0 until tableRows.size)

        var headers = colR.map { tableHeaders.getOrElse(it) { "" } }
        var rows = rowR.map { r -> colR.map { c -> tableRows.getOrElse(r) { emptyList() }.getOrElse(c) { "" } } }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f }
        var widths = headers.mapIndexed { i, h ->
            var w = paint.measureText(h)
            for (r in rows) w = max(w, paint.measureText(r.getOrElse(i) { "" }))
            min(200f, max(48f, w + 12f))
        }.toMutableList()

        val letterH = if (setup.rowColHeaders) 12f else 0f
        if (setup.rowColHeaders) {
            widths.add(0, 34f)
            headers = listOf("") + headers
            rows = rows.mapIndexed { i, r -> listOf((i + 1).toString()) + r }
        }

        val headH = 20f
        val rowH = 16f
        val tableW = widths.sum()
        val tableH = letterH + headH + rows.size * rowH

        val commentsH =
            if (setup.commentsMode == "工作表末尾" && comments.isNotEmpty()) 24f + comments.size * 14f
            else 0f

        val bodyTop = max(setup.headerTop + 14f, setup.marginTop)
        val pageW = setup.marginLeft + tableW + setup.marginRight
        val pageH = bodyTop + tableH + commentsH +
            max(setup.footerBottom + 14f, setup.marginBottom)

        return PageGeom(pageW, pageH, bodyTop, headers, rows, widths, rowH, headH, letterH, tableH)
    }

    // ---------------- 渲染 ----------------
    fun render(
        file: File,
        headers: List<HfVariant>,
        footers: List<HfVariant>,
        useFirstDiff: Boolean,
        useOddEven: Boolean,
        tableHeaders: List<String>,
        tableRows: List<List<String>>,
        comments: List<CellComment>,
        sheetName: String,
        fileName: String,
        path: String,
        setup: PageSetup
    ): Int {
        val geom = calcGeom(tableHeaders, tableRows, comments, setup)
        val pdf = PdfDocument()
        try {
            val w = geom.pageW.toInt().coerceAtLeast(1)
            val h = geom.pageH.toInt().coerceAtLeast(1)
            val page = pdf.startPage(PdfDocument.PageInfo.Builder(w, h, 1).create())
            val c = page.canvas
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)

            // 页眉 / 页脚（单页：普通变体；首页不同/奇偶页不同在单页下取首页规则）
            val hv = headers[if (useFirstDiff) 1 else 0]
            val fv = footers[if (useFirstDiff) 1 else 0]
            drawHf(c, paint, geom, hv, setup, 1, 1, setup.headerTop, fileName, path, sheetName)
            drawHf(c, paint, geom, fv, setup, 1, 1, geom.pageH - setup.footerBottom, fileName, path, sheetName)

            // 表格
            drawTable(c, paint, geom, comments, setup)

            // 批注（工作表末尾：表格下方）
            if (setup.commentsMode == "工作表末尾" && comments.isNotEmpty()) {
                drawComments(c, paint, geom, comments, setup)
            }

            FileOutputStream(file).use { pdf.writeTo(it) }
        } finally {
            pdf.close()
        }
        return 1
    }

    private fun drawTable(c: Canvas, paint: Paint, geom: PageGeom, comments: List<CellComment>, setup: PageSetup) {
        val x0 = setup.marginLeft
        var y = geom.bodyTop

        if (geom.letterH > 0) {
            paint.textSize = 8f * 1.2f
            paint.isFakeBoldText = true
            paint.color = 0xFF333333.toInt()
            for (i in geom.headers.indices) {
                val label = if (i == 0 && setup.rowColHeaders) "" else colLetter(i - (if (setup.rowColHeaders) 1 else 0))
                drawCenterFit(c, paint, label, x0 + geom.colW.subList(0, i).sum(), y, geom.colW[i], geom.letterH)
            }
            y += geom.letterH
        }

        // 表头行（加粗）
        paint.textSize = 10f
        paint.isFakeBoldText = true
        paint.color = 0xFF000000.toInt()
        var x = x0
        for (i in geom.headers.indices) {
            drawCenterFit(c, paint, geom.headers[i], x, y, geom.colW[i], geom.headH)
            x += geom.colW[i]
        }
        y += geom.headH

        // 数据行
        paint.isFakeBoldText = false
        for ((r, row) in geom.rows.withIndex()) {
            x = x0
            for (i in row.indices) {
                drawLeftFit(c, paint, row[i], x + 4f, y, geom.colW[i], geom.rowH)
                if (setup.commentsMode == "如同工作表中的显示") {
                    val cm = comments.firstOrNull { it.row == r && it.col + (if (setup.rowColHeaders) 1 else 0) == i }
                    if (cm != null) {
                        paint.color = 0xFFD0021B.toInt()
                        paint.textSize = 7f
                        c.drawText(fit(paint, "▣ " + cm.text, geom.colW[i] - 8f), x + 4f, y + geom.rowH - 2f, paint)
                        paint.color = 0xFF000000.toInt()
                        paint.textSize = 10f
                    }
                }
                x += geom.colW[i]
            }
            y += geom.rowH
        }

        // 网格（空格也有边框）
        if (setup.gridlines) {
            val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 0.5f
                color = 0xFF333333.toInt()
            }
            val top = geom.bodyTop
            val bottom = y
            c.drawRect(x0, top, x0 + geom.colW.sum(), bottom, line)
            var cx = x0
            for (w in geom.colW) {
                cx += w
                c.drawLine(cx, top, cx, bottom, line)
            }
            var ly = top
            if (geom.letterH > 0) {
                ly += geom.letterH
                c.drawLine(x0, ly, x0 + geom.colW.sum(), ly, line)
            }
            ly += geom.headH
            c.drawLine(x0, ly, x0 + geom.colW.sum(), ly, line)
            repeat(geom.rows.size) {
                ly += geom.rowH
                c.drawLine(x0, ly, x0 + geom.colW.sum(), ly, line)
            }
        }
    }

    private fun drawComments(c: Canvas, paint: Paint, geom: PageGeom, comments: List<CellComment>, setup: PageSetup) {
        var y = geom.bodyTop + geom.tableH + 16f
        paint.textSize = 10f
        paint.isFakeBoldText = true
        paint.color = 0xFF000000.toInt()
        c.drawText("批注", setup.marginLeft, y, paint)
        y += 16f
        paint.isFakeBoldText = false
        for (cm in comments) {
            paint.color = 0xFF2B5FC7.toInt()
            val ref = colLetter(cm.col) + (cm.row + 2).toString()
            c.drawText(ref, setup.marginLeft, y, paint)
            paint.color = 0xFF333333.toInt()
            c.drawText(fit(paint, cm.text, geom.pageW - setup.marginLeft - setup.marginRight - 42f), setup.marginLeft + 42f, y, paint)
            y += 14f
        }
    }

    /** 行内格式运行单元（&U/&u、&B/&b、&I/&i、&S/&s、&E/&e、&X/&x） */
    class Run(
        val text: String, val bold: Boolean, val italic: Boolean,
        val under: Int, val strike: Boolean, val sup: Boolean, val sub: Boolean
    )

    fun parseRuns(text: String, base: Fmt): List<Run> {
        val runs = mutableListOf<Run>()
        val sb = StringBuilder()
        var bold = base.bold
        var italic = base.italic
        var under = if (base.doubleUnderline) 2 else if (base.underline) 1 else 0
        var strike = base.strike
        var sup = base.superscript
        var sub = base.subscript

        fun flush() {
            if (sb.isNotEmpty()) {
                runs.add(Run(sb.toString(), bold, italic, under, strike, sup, sub))
                sb.clear()
            }
        }
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (ch == '&' && i + 1 < text.length) {
                when (text[i + 1]) {
                    'U' -> { flush(); under = 1; i += 2; continue }
                    'u' -> { flush(); under = 0; i += 2; continue }
                    'B' -> { flush(); bold = true; i += 2; continue }
                    'b' -> { flush(); bold = false; i += 2; continue }
                    'I' -> { flush(); italic = true; i += 2; continue }
                    'i' -> { flush(); italic = false; i += 2; continue }
                    'S' -> { flush(); strike = true; i += 2; continue }
                    's' -> { flush(); strike = false; i += 2; continue }
                    'E' -> { flush(); sup = true; i += 2; continue }
                    'e' -> { flush(); sup = false; i += 2; continue }
                    'X' -> { flush(); sub = true; i += 2; continue }
                    'x' -> { flush(); sub = false; i += 2; continue }
                }
            }
            sb.append(ch)
            i++
        }
        flush()
        return runs
    }

    private fun drawHf(
        c: Canvas, paint: Paint, geom: PageGeom,
        v: HfVariant, setup: PageSetup,
        pageNum: Int, totalPages: Int, y: Float,
        fileName: String, path: String, sheetName: String
    ) {
        for (col in 0..2) {
            val raw = v.texts[col]
            val fmt = v.fmts[col]
            val text = resolve(raw, pageNum, totalPages, fileName, path, sheetName, true)
            if (raw.isBlank() && fmt.image == null) continue

            // 有网格：最外字与框线对齐、不超出（左右向中间缩半角）；无网格：以边距为准
            val inset = if (setup.gridlines) fmt.size * 0.5f else 0f
            val anchorX = when (col) {
                0 -> setup.marginLeft + inset
                1 -> geom.pageW / 2f
                else -> geom.pageW - setup.marginRight - inset
            }

            val img = fmt.image
            if (img != null && !img.isRecycled && !setup.draft) {
                val targetH = 26f
                val w = targetH * (img.width.toFloat() / img.height)
                val ix = when (col) {
                    0 -> anchorX
                    1 -> anchorX - w / 2f
                    else -> anchorX - w
                }
                val top = if (text.isBlank()) y - targetH else y - fmt.size - targetH - 2f
                c.drawBitmap(img, null, RectF(ix, top, ix + w, top + targetH), paint)
            }

            if (text.isBlank()) continue

            val runs = parseRuns(text, fmt)
            val widths = FloatArray(runs.size)
            var total = 0f
            for ((i, r) in runs.withIndex()) {
                paint.typeface = typefaceOf(fmt.font, r.bold, r.italic)
                paint.textSize = if (r.sup || r.sub) fmt.size * 0.72f else fmt.size
                widths[i] = paint.measureText(r.text)
                total += widths[i]
            }

            var x = when (col) {
                0 -> anchorX
                1 -> anchorX - total / 2f
                else -> anchorX - total
            }

            for ((i, r) in runs.withIndex()) {
                paint.typeface = typefaceOf(fmt.font, r.bold, r.italic)
                paint.textSize = if (r.sup || r.sub) fmt.size * 0.72f else fmt.size
                paint.color = if (setup.mono) 0xFF000000.toInt() else fmt.color
                val ty = when {
                    r.sup -> y - fmt.size * 0.34f
                    r.sub -> y + fmt.size * 0.20f
                    else -> y
                }
                c.drawText(r.text, x, ty, paint)

                val w = widths[i]
                val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 1f
                    color = paint.color
                }
                when (r.under) {
                    1 -> c.drawLine(x, ty + 3f, x + w, ty + 3f, line)     // 连续下划线（含空格）
                    2 -> {
                        c.drawLine(x, ty + 2.5f, x + w, ty + 2.5f, line)
                        c.drawLine(x, ty + 5f, x + w, ty + 5f, line)
                    }
                }
                if (r.strike) c.drawLine(x, ty - paint.textSize * 0.3f, x + w, ty - paint.textSize * 0.3f, line)
                x += w
            }
        }
        paint.textAlign = Paint.Align.LEFT
        paint.typeface = Typeface.DEFAULT
    }

    private val typefaceCache = HashMap<String, Typeface>()

    // 默认字体（空＝系统默认）；字体只用系统真实字体 / 用户导入字体
    @Volatile
    var defaultFont: String = ""

    fun typefaceOf(font: String, bold: Boolean, italic: Boolean): Typeface {
        val f0 = font.ifBlank { defaultFont }
        val key = "$f0|$bold|$italic"
        return typefaceCache.getOrPut(key) {
            val style = when {
                bold && italic -> Typeface.BOLD_ITALIC
                bold -> Typeface.BOLD
                italic -> Typeface.ITALIC
                else -> Typeface.NORMAL
            }
            val base = if (f0.startsWith("/") || f0.endsWith(".ttf") ||
                f0.endsWith(".otf") || f0.endsWith(".ttc")
            ) {
                try {
                    Typeface.createFromFile(File(f0))
                } catch (_: Exception) {
                    Typeface.DEFAULT
                }
            } else {
                when (f0) {
                    "黑体", "Arial", "Verdana", "Calibri", "Tahoma", "幼圆" -> Typeface.SANS_SERIF
                    "Courier New", "Consolas" -> Typeface.MONOSPACE
                    else -> Typeface.SERIF
                }
            }
            Typeface.create(base, style)
        }
    }

    private fun drawCenterFit(c: Canvas, p: Paint, t: String, x: Float, y: Float, w: Float, h: Float) {
        val text = fit(p, t, w - 8f)
        val tw = p.measureText(text)
        c.drawText(text, x + (w - tw) / 2f, y + h / 2f + p.textSize / 2.6f, p)
    }

    private fun drawLeftFit(c: Canvas, p: Paint, t: String, x: Float, y: Float, w: Float, h: Float) {
        c.drawText(fit(p, t, w - 8f), x, y + h / 2f + p.textSize / 2.6f, p)
    }

    fun fit(p: Paint, t: String, maxW: Float): String {
        if (t.isEmpty() || maxW <= 0f) return ""
        if (p.measureText(t) <= maxW) return t
        var s = t
        while (s.isNotEmpty() && p.measureText("$s…") > maxW) s = s.dropLast(1)
        return if (s.isEmpty()) "" else "$s…"
    }

    private fun colLetter(index: Int): String {
        var i = index
        val sb = StringBuilder()
        while (i >= 0) {
            sb.insert(0, ('A' + i % 26))
            i = i / 26 - 1
        }
        return sb.toString()
    }

    fun previewText(s: String, fileName: String, sheetName: String, path: String = ""): String =
        resolve(s, 1, 1, fileName, path, sheetName)

    /** 格式码：&& 字面 &；&Z&F 路径+文件名；&P 页码；&N 总页；&F 文件名；&A 表名；&D 日期；&T 时间 */
    fun resolve(
        s: String, p: Int, n: Int, fn: String, path: String, sn: String,
        keepToggles: Boolean = false
    ): String {
        val now = Date()
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(now)
        val t = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)

        var r = s.replace("&&", LITERAL)
        r = Regex("&[Zz]&[Ff]").replace(r) { path + fn }
        r = Regex("&[Zz]").replace(r) { path }
        r = Regex("&[Ff]").replace(r) { fn }
        r = Regex("&[Pp]").replace(r) { p.toString() }
        r = Regex("&[Nn]").replace(r) { n.toString() }
        r = Regex("&[Aa]").replace(r) { sn }
        r = Regex("&[Dd]").replace(r) { d }
        r = Regex("&[Tt]").replace(r) { t }
        if (!keepToggles) r = Regex("&[BIUSbiusEXex]").replace(r, "")
        return r.replace(LITERAL, "&")
    }
}
