package com.excel.header

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * 打印预览视口 —— 与打印输出完全一致（单页 PDF，尺寸随表格）。
 * 默认全部显示（fit），支持双指缩放、拖拽平移、双击复位。
 */
class PreviewView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    var header: HfVariant = HfVariant()
    var footer: HfVariant = HfVariant()
    var tableHeaders: List<String> = emptyList()
    var tableRows: List<List<String>> = emptyList()
    var comments: List<CellComment> = emptyList()
    var setup: PageSetup = PageSetup()

    private var geom: PageGeom? = null
    private var scale = 1f
    private var tx = 0f
    private var ty = 0f
    private var fitted = false

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val ns = (scale * d.scaleFactor).coerceIn(0.05f, 8f)
                val k = ns / scale
                tx = d.focusX - (d.focusX - tx) * k
                ty = d.focusY - (d.focusY - ty) * k
                scale = ns
                invalidate()
                return true
            }
        })

    private val gestureDetector = GestureDetector(context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onScroll(
                e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float
            ): Boolean {
                tx -= dx
                ty -= dy
                invalidate()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                fitToView()
                return true
            }
        })

    fun update(
        header: HfVariant,
        footer: HfVariant,
        tableHeaders: List<String>,
        tableRows: List<List<String>>,
        comments: List<CellComment>,
        setup: PageSetup
    ) {
        this.header = header
        this.footer = footer
        this.tableHeaders = tableHeaders
        this.tableRows = tableRows
        this.comments = comments
        this.setup = setup
        geom = PdfRenderer.calcGeom(tableHeaders, tableRows, comments, setup)
        fitted = false
        requestLayout()
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        setMeasuredDimension(
            w,
            if (MeasureSpec.getMode(heightMeasureSpec) == MeasureSpec.UNSPECIFIED) w else h
        )
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (!fitted) fitToView()
    }

    /** 默认全部显示 */
    private fun fitToView() {
        val g = geom ?: return
        val vw = width.toFloat()
        val vh = height.toFloat()
        if (vw <= 0 || vh <= 0 || g.pageW <= 0 || g.pageH <= 0) return
        val s = min(vw / g.pageW, vh / g.pageH) * 0.95f
        scale = s
        tx = (vw - g.pageW * s) / 2f
        ty = (vh - g.pageH * s) / 2f
        fitted = true
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)
        return true
    }

    override fun onDraw(canvas: Canvas) {
        val g = geom ?: return
        canvas.save()
        canvas.translate(tx, ty)
        canvas.scale(scale, scale)

        // 页面
        paint.style = Paint.Style.FILL
        paint.color = 0xFFFFFFFF.toInt()
        canvas.drawRect(0f, 0f, g.pageW, g.pageH, paint)
        paint.style = Paint.Style.STROKE
        paint.color = 0xFFBFBFBF.toInt()
        paint.strokeWidth = 1f / scale
        canvas.drawRect(0f, 0f, g.pageW, g.pageH, paint)
        paint.style = Paint.Style.FILL

        drawHf(canvas, header, setup.headerTop)
        drawHf(canvas, footer, g.pageH - setup.footerBottom)
        drawTable(canvas, g)

        canvas.restore()
    }

    private fun drawTable(c: Canvas, g: PageGeom) {
        val x0 = setup.marginLeft
        var y = g.bodyTop

        if (g.letterH > 0) {
            paint.textSize = 8f
            paint.isFakeBoldText = true
            paint.color = 0xFF333333.toInt()
            for (i in g.headers.indices) {
                val label =
                    if (i == 0 && setup.rowColHeaders) ""
                    else PdfRenderer.fit(paint, colLetter(i - (if (setup.rowColHeaders) 1 else 0)), g.colW[i] - 8f)
                drawCenter(c, label, x0 + g.colW.subList(0, i).sum(), y, g.colW[i], g.letterH)
            }
            y += g.letterH
        }

        // 表头（加粗）
        paint.textSize = 10f
        paint.isFakeBoldText = true
        paint.color = 0xFF000000.toInt()
        var x = x0
        for (i in g.headers.indices) {
            drawCenter(c, PdfRenderer.fit(paint, g.headers[i], g.colW[i] - 8f), x, y, g.colW[i], g.headH)
            x += g.colW[i]
        }
        y += g.headH

        // 数据行
        paint.isFakeBoldText = false
        for (row in g.rows) {
            x = x0
            for (i in row.indices) {
                paint.color = 0xFF333333.toInt()
                c.drawText(PdfRenderer.fit(paint, row[i], g.colW[i] - 8f), x + 4f, y + g.rowH / 2f + paint.textSize / 2.6f, paint)
                x += g.colW[i]
            }
            y += g.rowH
        }

        // 网格（空格也有边框）
        if (setup.gridlines) {
            val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 0.5f
                color = 0xFF333333.toInt()
            }
            val top = g.bodyTop
            c.drawRect(x0, top, x0 + g.colW.sum(), y, line)
            var cx = x0
            for (w in g.colW) {
                cx += w
                c.drawLine(cx, top, cx, y, line)
            }
            var ly = top
            if (g.letterH > 0) {
                ly += g.letterH
                c.drawLine(x0, ly, x0 + g.colW.sum(), ly, line)
            }
            ly += g.headH
            c.drawLine(x0, ly, x0 + g.colW.sum(), ly, line)
            repeat(g.rows.size) {
                ly += g.rowH
                c.drawLine(x0, ly, x0 + g.colW.sum(), ly, line)
            }
        }
    }

    /** 页眉/页脚（左中右自动对齐；行内格式同 PDF 渲染） */
    private fun drawHf(c: Canvas, v: HfVariant, y: Float) {
        val g = geom ?: return
        for (col in 0..2) {
            val raw = v.texts[col]
            val fmt = v.fmts[col]
            val text = PdfRenderer.resolve(raw, 1, 1, "", "", "", true)
            if (raw.isBlank() && fmt.image == null) continue

            val inset = if (setup.gridlines) fmt.size * 0.5f else 0f
            val anchorX = when (col) {
                0 -> setup.marginLeft + inset
                1 -> g.pageW / 2f
                else -> g.pageW - setup.marginRight - inset
            }

            val img = fmt.image
            if (img != null && !img.isRecycled && !setup.draft) {
                val th = 22f
                val tw = th * (img.width.toFloat() / img.height)
                val ix = when (col) {
                    0 -> anchorX
                    1 -> anchorX - tw / 2f
                    else -> anchorX - tw
                }
                val top = if (text.isBlank()) y - th else y - fmt.size - th - 2f
                c.drawBitmap(img, null, RectF(ix, top, ix + tw, top + th), paint)
            }
            if (text.isBlank()) continue

            val runs = PdfRenderer.parseRuns(text, fmt)
            val widths = FloatArray(runs.size)
            var total = 0f
            for ((i, r) in runs.withIndex()) {
                paint.typeface = PdfRenderer.typefaceOf(fmt.font, r.bold, r.italic)
                paint.textSize = if (r.sup || r.sub) fmt.size * 0.72f else fmt.size
                widths[i] = paint.measureText(r.text)
                total += widths[i]
            }
            var x = when (col) {
                0 -> anchorX
                1 -> anchorX - total / 2f
                else -> anchorX - total
            }
            for ((i, r) in runs.withIndex()) {
                paint.typeface = PdfRenderer.typefaceOf(fmt.font, r.bold, r.italic)
                paint.textSize = if (r.sup || r.sub) fmt.size * 0.72f else fmt.size
                paint.color = if (setup.mono) 0xFF000000.toInt() else fmt.color
                val ty = when {
                    r.sup -> y - fmt.size * 0.34f
                    r.sub -> y + fmt.size * 0.20f
                    else -> y
                }
                c.drawText(r.text, x, ty, paint)
                val w = widths[i]
                val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 1f
                    color = paint.color
                }
                when (r.under) {
                    1 -> c.drawLine(x, ty + 3f, x + w, ty + 3f, line)   // 连续下划线（含空格）
                    2 -> {
                        c.drawLine(x, ty + 2.5f, x + w, ty + 2.5f, line)
                        c.drawLine(x, ty + 5f, x + w, ty + 5f, line)
                    }
                }
                if (r.strike) c.drawLine(x, ty - paint.textSize * 0.3f, x + w, ty - paint.textSize * 0.3f, line)
                x += w
            }
        }
    }

    private fun drawCenter(c: Canvas, t: String, x: Float, y: Float, w: Float, h: Float) {
        val tw = paint.measureText(t)
        paint.textAlign = Paint.Align.LEFT
        c.drawText(t, x + (w - tw) / 2f, y + h / 2f + paint.textSize / 2.6f, paint)
    }

    private fun colLetter(index: Int): String {
        var i = index
        val sb = StringBuilder()
        while (i >= 0) {
            sb.insert(0, ('A' + i % 26))
            i = i / 26 - 1
        }
        return sb.toString()
    }
}
